package com.order.project.service;

import com.order.project.entity.Ingredient;
import com.order.project.repository.IngredientRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* Ingredient service implementaion class.
*/
@Service
public class IngredientServiceImpl implements IngredientService {

  @Autowired
  private IngredientRepository ingRepo;

  @Override
  public List<Ingredient> getAllIngredient() {
    return ingRepo.findAll();
  }

  @Override
  public Ingredient addItem(Ingredient item) {
    return ingRepo.save(item);
  }

  @Override
  public Ingredient updateItem(Ingredient item) {
    ingRepo.save(item);
    return item;
  }

  @Override
  public void deleteItem(Integer id) {
    ingRepo.deleteById(id);
  }
}
