package com.order.project.repository;

import com.order.project.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository interface for Category.
 */
public interface CategoryRepository extends JpaRepository<Category, Integer> {
}