package com.order.project.repository;

import com.order.project.entity.Ingredient;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository interface for Ingredient.
 */
public interface IngredientRepository extends JpaRepository<Ingredient, Integer> {
}