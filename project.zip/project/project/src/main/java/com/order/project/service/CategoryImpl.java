package com.order.project.service;

import com.order.project.entity.Category;
import com.order.project.repository.CategoryRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Category service implementaion class.
 */
@Service
public class CategoryImpl implements CategoryService {
  @Autowired
  private CategoryRepository catRepo;

  @Override
  public List<Category> getAllCategory() {
    return catRepo.findAll();
  }

  @Override
  public Category addItem(Category item) {
    return catRepo.save(item);
  }

  @Override
  public Category updateItem(Category item) {
    catRepo.save(item);
    return item;
  }

  @Override
  public void deleteItem(Integer id) {
    catRepo.deleteById(id);
  }
}
