package com.order.project.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.order.project.entity.OpHrs;
import com.order.project.entity.Restaurant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Dto class for operational hours.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OpHrsDto2 {

    private Integer opid;

    private String dayofweek;

    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private Restaurant restaurant;

    public OpHrsDto2 V2(OpHrs oph2) {
        return new OpHrsDto2 (
                oph2.getOpid(),
                oph2.getDayofweek(),
                oph2.getRestaurant()
        );
    }
}

