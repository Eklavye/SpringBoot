package com.order.project.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.order.project.entity.Restaurant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* Dto class for operational hours.
*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OpHrsDto {

  private Integer opid;

  private String dayofweek;

  private String start;

  private String end;

  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  private Restaurant restaurant;
}
