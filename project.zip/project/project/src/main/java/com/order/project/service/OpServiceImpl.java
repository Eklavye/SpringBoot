package com.order.project.service;

import com.order.project.entity.OpHrs;
import com.order.project.repository.OpRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* Operational hours service implementaion class.
*/
@Service
public class OpServiceImpl implements OpService {
  @Autowired
  private OpRepository opRepo;

  @Override
  public List<OpHrs> getAllOpHrs() {
    return opRepo.findAll();
  }

  @Override
  public OpHrs addItem(OpHrs oph) {
    return opRepo.save(oph);
  }

  @Override
  public OpHrs updateItem(OpHrs oph) {
    opRepo.save(oph);
    return oph;
  }

  @Override
  public void deleteItem(Integer id) {
    opRepo.deleteById(id);
  }
}
