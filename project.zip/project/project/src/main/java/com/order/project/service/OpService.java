package com.order.project.service;

import com.order.project.entity.OpHrs;
import java.util.List;

/**
 * Service interface for Operational Hrs.
 */
public interface OpService {
  List<OpHrs> getAllOpHrs();

  OpHrs addItem(OpHrs oph);

  OpHrs updateItem(OpHrs oph);

  void deleteItem(Integer id);
}
