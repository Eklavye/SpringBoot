package com.order.project.service;

import com.order.project.entity.Restaurant;
import com.order.project.repository.RestaurantRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* Restaurant service implementaion class.
*/
@Service
public class RestServiceImpl implements RestService {
  @Autowired
  private RestaurantRepository restRepo;

  @Override
  public List<Restaurant> getAllRestaurants() {
    return restRepo.findAll();
  }

  @Override
  public Restaurant addRestaurant(Restaurant rest) {
    return restRepo.save(rest);
  }

  @Override
  public Restaurant updateRestaurant(Restaurant rest) {
    restRepo.save(rest);
    return rest;
  }

  @Override
  public void deleteRestaurant(Integer id) {
    restRepo.deleteById(id);
  }
}
