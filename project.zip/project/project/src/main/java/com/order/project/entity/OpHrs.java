package com.order.project.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Operational hour table.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "ophrs", schema = "user_db", indexes = {
  @Index(name = "restaurantid", columnList = "restaurantid")
})
public class OpHrs {
  @Id
  @Column(name = "opid", nullable = false)
  private Integer opid;

  @Column(name = "dayofweek", length = 100)
  private String dayofweek;

  public Integer getOpid() {
    return opid;
  }

  public void setOpid(Integer opid) {
    this.opid = opid;
  }

  public String getStart() {
    return start;
  }

  public void setStart(String start) {
    this.start = start;
  }

  public String getEnd() {
    return end;
  }

  public void setEnd(String end) {
    this.end = end;
  }

  @Column(name = "start", length = 100)
  private String start;

  @Column(name = "end", length = 100)
  private String end;

  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "restaurantid")
  private Restaurant restaurant;

  public void setDayofweek(String dayofweek) {
    this.dayofweek = dayofweek;
  }

  public Restaurant getRestaurant() {
    return restaurant;
  }

  public void setRestaurant(Restaurant restaurant) {
    this.restaurant = restaurant;
  }
}