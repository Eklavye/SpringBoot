package com.order.project.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.order.project.entity.Restaurant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* Dto class for restaurant.
*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RestaurantDto {

  private int restaurantid;

  private String restaurantname;

  private String address;

  private String email;

  private String phone;

}
