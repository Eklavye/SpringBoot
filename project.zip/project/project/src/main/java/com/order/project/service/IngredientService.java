package com.order.project.service;

import com.order.project.entity.Ingredient;
import java.util.List;

/**
 * Service class for Ingredient.
 */

public interface IngredientService {
  List<Ingredient> getAllIngredient();

  Ingredient addItem(Ingredient item);

  Ingredient updateItem(Ingredient item);

  void deleteItem(Integer id);
}