package com.order.project.service;

import com.order.project.entity.Restaurant;
import java.util.List;

/**
* Service interface for Restaurant.
*/
public interface RestService {
  List<Restaurant> getAllRestaurants();

  Restaurant addRestaurant(Restaurant rest);

  Restaurant updateRestaurant(Restaurant rest);

  void deleteRestaurant(Integer id);
}
