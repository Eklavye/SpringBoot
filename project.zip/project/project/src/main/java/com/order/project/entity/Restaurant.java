package com.order.project.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Restaurant Table with.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "Restaurant")
public class Restaurant {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column
  private int restaurantid;
  @Column
  private String restaurantname;
  @Column
  private String address;
  @Column
  private String email;
  @Column
  private String phone;

  public int getRestaurantid() {
    return restaurantid;
  }

  public void setRestaurantid(int restaurantid) {
    this.restaurantid = restaurantid;
  }

  public String getRestaurantname() {
    return restaurantname;
  }

  public void setRestaurantname(String restaurantname) {
    this.restaurantname = restaurantname;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

}
