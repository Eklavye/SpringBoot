package com.order.project.controller;

import com.order.project.dto.OpHrsDto;
import com.order.project.dto.OpHrsDto2;
import com.order.project.dto.RestaurantDto2;
import com.order.project.entity.OpHrs;
import com.order.project.service.OpService;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller class for Operational hours.
 */
@RestController
@RequestMapping(value = "/op")
public class OpController {
  @Autowired
  private ModelMapper modelMapper;

  @Autowired
  private OpService opServ;

  @GetMapping("/v1")
  public List<OpHrsDto> getAllOpHrsV1() {
    return opServ.getAllOpHrs().stream()
            .map(opHrs -> modelMapper.map(opHrs, OpHrsDto.class)).toList();
  }

  @GetMapping("/v2")
  public List<OpHrsDto2> getAllOpHrsV2() {
    return opServ.getAllOpHrs().stream()
            .map(opHrs -> modelMapper.map(opHrs, OpHrsDto2.class)).toList();
  }

  /**
   * Adds item.
   */
  @PostMapping(value = "/")
  public ResponseEntity<OpHrsDto> addItem(@RequestBody OpHrsDto ophdto) {
    OpHrs opRequest = modelMapper.map(ophdto, OpHrs.class);
    OpHrs oph = opServ.addItem(opRequest);

    modelMapper.map(oph, OpHrsDto.class);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  /**
   * Updates item.
   */
  @PutMapping(value = "/{id}")
  public ResponseEntity<OpHrsDto> updateItem(@PathVariable Integer id,
                                             @RequestBody OpHrsDto ophdto) {
    OpHrs opRequest = modelMapper.map(ophdto, OpHrs.class);
    OpHrs oph = opServ.updateItem(opRequest);

    modelMapper.map(oph, OpHrsDto.class);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  /**
   * Deletes item.
   */
  @DeleteMapping(value = "/{id}")
  public void deleteItem(@PathVariable Integer id) {
    opServ.deleteItem(id);
  }
}