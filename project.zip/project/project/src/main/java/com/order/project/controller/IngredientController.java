package com.order.project.controller;

import com.order.project.dto.IngredientDto;
import com.order.project.entity.Ingredient;
import com.order.project.service.IngredientService;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller class for Ingredient.
 */
@RestController
@RequestMapping("/ing")
public class IngredientController {
  @Autowired
  private ModelMapper modelMapper;
  @Autowired
  private IngredientService ingserv;

  @GetMapping("/")
  public List<IngredientDto> getAllIngredient() {
    return ingserv.getAllIngredient().stream()
            .map(ing -> modelMapper.map(ing, IngredientDto.class)).toList();
  }

  /**
   * Adds item.
   */
  @PostMapping(value = "/")
  public ResponseEntity<IngredientDto> addIngredient(@RequestBody IngredientDto ingdto) {
    Ingredient ingRequest = modelMapper.map(ingdto, Ingredient.class);
    Ingredient item = ingserv.addItem(ingRequest);

    modelMapper.map(item, IngredientDto.class);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  /**
   * Updates item.
   */
  @PutMapping(value = "/{id}")
  public ResponseEntity<IngredientDto> updateItem(@PathVariable Integer id,
                                                  @RequestBody IngredientDto ingdto) {
    Ingredient ingRequest = modelMapper.map(ingdto, Ingredient.class);
    Ingredient item = ingserv.updateItem(ingRequest);

    modelMapper.map(item, IngredientDto.class);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  /**
   * Deletes item.
   */
  @DeleteMapping(value = "/{id}")
  public void deleteItem(@PathVariable Integer id) {
    ingserv.deleteItem(id);
  }
}