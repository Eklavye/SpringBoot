package com.order.project.controller;

import com.order.project.dto.MenuDto;
import com.order.project.entity.Menu;
import com.order.project.service.MenuService;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller class for Menu.
 */
@RestController
@RequestMapping("/menu")
public class MenuController {

  @Autowired
  private ModelMapper modelMapper;
  @Autowired
  private MenuService menuserv;

  @GetMapping("/")
  public List<MenuDto> getAllItem() {
    return menuserv.getAllItem().stream()
            .map(menu -> modelMapper.map(menu, MenuDto.class)).toList();
  }

  /**
   * Adds item.
   */
  @PostMapping(value = "/")
  public ResponseEntity<MenuDto> addMenu(@RequestBody MenuDto menudto) {
    Menu menuRequest = modelMapper.map(menudto, Menu.class);
    Menu item = menuserv.addItem(menuRequest);

    modelMapper.map(item, MenuDto.class);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  /**
   * Updates item.
   */
  @PutMapping(value = "/{id}")
  public ResponseEntity<MenuDto> updateItem(@PathVariable Integer id,
                                            @RequestBody MenuDto menudto) {
    Menu menuRequest = modelMapper.map(menudto, Menu.class);
    Menu item = menuserv.updateItem(menuRequest);

    modelMapper.map(item, MenuDto.class);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  /**
   * Deletes item.
   */
  @DeleteMapping(value = "/{id}")
  public void deleteItem(@PathVariable Integer id) {
    menuserv.deleteItem(id);
  }
}
