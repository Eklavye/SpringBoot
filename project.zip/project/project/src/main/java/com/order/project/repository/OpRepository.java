package com.order.project.repository;

import com.order.project.entity.OpHrs;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository interface for Operational Hours.
 */
public interface OpRepository extends JpaRepository<OpHrs, Integer> {
}