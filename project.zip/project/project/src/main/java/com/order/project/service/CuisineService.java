package com.order.project.service;

import com.order.project.entity.Cuisine;
import java.util.List;

/**
 * Service class for Cuisine.
 */
public interface CuisineService {
  List<Cuisine> getAllCuisine();

  Cuisine addItem(Cuisine item);

  Cuisine updateItem(Cuisine item);

  void deleteItem(Integer id);
}