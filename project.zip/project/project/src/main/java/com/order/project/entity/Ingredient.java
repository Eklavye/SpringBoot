package com.order.project.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Ingredients Table contents.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "ingredient", schema = "user_db", indexes = {
    @Index(name = "restaurantid", columnList = "restaurantid")
})
public class Ingredient {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "ingredientid", nullable = false)
  private Integer ingredientid;

  public Integer getIngredientid() {
    return ingredientid;
  }

  public void setIngredientid(Integer ingredientid) {
    this.ingredientid = ingredientid;
  }

  @Column(name = "ingredientname", length = 100)
  private String ingredientname;

  public String getIngredientname() {
    return ingredientname;
  }

  public void setIngredientname(String ingredientname) {
    this.ingredientname = ingredientname;
  }

  @Column(name = "expirydate", length = 100)
  private String expirydate;

  public String getExpirydate() {
    return expirydate;
  }

  public void setExpirydate(String expirydate) {
    this.expirydate = expirydate;
  }

  @Column(name = "quantity")
  private Integer quantity;

  public Integer getQuantity() {
    return quantity;
  }

  public void setQuantity(Integer quantity) {
    this.quantity = quantity;
  }

  @Column(name = "price")
  private Integer price;

  public Integer getPrice() {
    return price;
  }

  public void setPrice(Integer price) {
    this.price = price;
  }

  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "restaurantid")
  private Restaurant restaurant;

  public Restaurant getRestaurant() {
    return restaurant;
  }

  public void setRestaurant(Restaurant restaurant) {
    this.restaurant = restaurant;
  }

}