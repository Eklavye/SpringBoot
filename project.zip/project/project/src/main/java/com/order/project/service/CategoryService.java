package com.order.project.service;

import com.order.project.entity.Category;
import java.util.List;

/**
 * Service class for Category.
 */
public interface CategoryService {

  List<Category> getAllCategory();

  Category addItem(Category cat);

  Category updateItem(Category cat);

  void deleteItem(Integer id);
}