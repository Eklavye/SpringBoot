package com.order.project.repository;

import com.order.project.entity.Cuisine;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository interface for Cuisine.
 */
public interface CuisineRepository extends JpaRepository<Cuisine, Integer> {
}