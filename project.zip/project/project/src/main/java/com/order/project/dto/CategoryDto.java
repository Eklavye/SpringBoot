package com.order.project.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.order.project.entity.Cuisine;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* Dto class for category.
*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryDto {
  private Integer categoryid;

  private String categoryname;

  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  private Cuisine cuisine;
}
