package com.order.project.repository;

import com.order.project.entity.Menu;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository interface for Menu.
 */
public interface MenuRepository extends JpaRepository<Menu, Integer> {
}