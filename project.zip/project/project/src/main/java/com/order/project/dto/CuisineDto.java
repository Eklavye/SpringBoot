package com.order.project.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.order.project.entity.Restaurant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* Dto class for cuisine.
*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CuisineDto {

  private Integer cuisineid;

  private String cuisinename;

  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  private Restaurant restaurant;
}
