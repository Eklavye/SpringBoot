package com.order.project.service;

import com.order.project.entity.Menu;
import com.order.project.repository.MenuRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* Menu service implementaion class.
*/
@Service
public class MenuServiceImpl implements MenuService {

  @Autowired
  private MenuRepository menuRepository;

  @Override
  public List<Menu> getAllItem() {
    return menuRepository.findAll();
  }

  @Override
  public Menu addItem(Menu item) {
    return menuRepository.save(item);
  }

  @Override
  public Menu updateItem(Menu item) {
    menuRepository.save(item);
    return item;
  }

  @Override
  public void deleteItem(Integer id) {
    menuRepository.deleteById(id);
  }
}
