package com.order.project.controller;

import com.order.project.dto.CuisineDto;
import com.order.project.entity.Cuisine;
import com.order.project.service.CuisineService;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller class for Cuisine.
 */
@RestController
@RequestMapping("/cui")
public class CuisineController {
  @Autowired
  private ModelMapper modelMapper;
  @Autowired
  private CuisineService cuiserv;

  @GetMapping("/")
  public List<CuisineDto> getAllCuisine() {
    return cuiserv.getAllCuisine().stream()
            .map(cui -> modelMapper.map(cui, CuisineDto.class)).toList();
  }

  /**
   * Adds item.
   */
  @PostMapping(value = "/")
  public ResponseEntity<CuisineDto> addCuisine(@RequestBody CuisineDto cuidto) {
    Cuisine cuiRequest = modelMapper.map(cuidto, Cuisine.class);
    Cuisine item = cuiserv.addItem(cuiRequest);

    modelMapper.map(item, CuisineDto.class);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  /**
   * Updates item.
   */
  @PutMapping(value = "/{id}")
  public ResponseEntity<CuisineDto> updateItem(@PathVariable Integer id,
                                               @RequestBody CuisineDto cuidto) {
    Cuisine cuiRequest = modelMapper.map(cuidto, Cuisine.class);
    Cuisine item = cuiserv.updateItem(cuiRequest);

    modelMapper.map(item, CuisineDto.class);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  /**
   * Deletes item.
   */
  @DeleteMapping(value = "/{id}")
  public void deleteItem(@PathVariable Integer id) {
    cuiserv.deleteItem(id);
  }
}