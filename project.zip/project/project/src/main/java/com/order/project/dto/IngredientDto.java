package com.order.project.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.order.project.entity.Restaurant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* Dto class for ingredient.
*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IngredientDto {

  private Integer ingredientid;

  private String expirydate;

  private String ingredientname;

  private Integer price;

  private Integer quantity;

  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  private Restaurant restaurant;
}
