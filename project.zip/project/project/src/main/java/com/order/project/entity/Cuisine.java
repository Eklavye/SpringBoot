package com.order.project.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Cuisine Table contents.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "cuisine", schema = "user_db", indexes = {
    @Index(name = "restaurantid", columnList = "restaurantid")
})
public class Cuisine {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "cuisineid", nullable = false)
  private Integer cuisineid;

  @Column(name = "cuisinename", length = 100)
  private String cuisinename;

  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "restaurantid")
  private Restaurant restaurant;

  public Integer getCuisineid() {
    return cuisineid;
  }

  public void setCuisineid(Integer cuisineid) {
    this.cuisineid = cuisineid;
  }

  public String getCuisinename() {
    return cuisinename;
  }

  public void setCuisinename(String cuisinename) {
    this.cuisinename = cuisinename;
  }

  public Restaurant getRestaurant() {
    return restaurant;
  }

  public void setRestaurant(Restaurant restaurant) {
    this.restaurant = restaurant;
  }

}