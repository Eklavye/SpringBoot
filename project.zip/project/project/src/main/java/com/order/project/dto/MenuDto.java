package com.order.project.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.order.project.entity.Category;
import com.order.project.entity.Cuisine;
import com.order.project.entity.Ingredient;
import com.order.project.entity.Restaurant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* Dto class for menu.
*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MenuDto {

  private Integer itemid;

  private String itemname;

  private Integer price;

  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  private Cuisine cuisine;

  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  private Category category;

  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  private Ingredient ingredient;

  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  private Restaurant restaurant;

}
