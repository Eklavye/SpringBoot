package com.order.project.service;

import com.order.project.entity.Menu;
import java.util.List;

/**
* Service interface for Menu.
*/
public interface MenuService {
  List<Menu> getAllItem();

  Menu addItem(Menu item);

  Menu updateItem(Menu item);

  void deleteItem(Integer id);
}
