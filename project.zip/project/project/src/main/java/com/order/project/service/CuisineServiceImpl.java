package com.order.project.service;

import com.order.project.entity.Cuisine;
import com.order.project.repository.CuisineRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* Cuisine service implementaion class.
*/
@Service
public class CuisineServiceImpl implements CuisineService {

  @Autowired
  private CuisineRepository cuiRepo;

  @Override
  public List<Cuisine> getAllCuisine() {
    return cuiRepo.findAll();
  }

  @Override
  public Cuisine addItem(Cuisine item) {
    return cuiRepo.save(item);
  }

  @Override
  public Cuisine updateItem(Cuisine item) {
    cuiRepo.save(item);
    return item;
  }

  @Override
  public void deleteItem(Integer id) {
    cuiRepo.deleteById(id);
  }
}
