package com.order.project.controller;

import com.order.project.dto.RestaurantDto;
import com.order.project.dto.RestaurantDto2;
import com.order.project.entity.Restaurant;
import com.order.project.service.RestService;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller class for Restaurant.
 */
@RestController
@RequestMapping("/rests")
public class RestaurantController {
  @Autowired
  private ModelMapper modelMapper;

  @Autowired
  private RestService restServ;

  @GetMapping("/v1")
  public List<RestaurantDto> getAllRestaurantsV1() {
    return restServ.getAllRestaurants().stream()
            .map(restaurant -> modelMapper.map(restaurant, RestaurantDto.class)).toList();
  }

  @GetMapping("/v2")
  public List<RestaurantDto2> getAllRestaurantsV2() {
    return restServ.getAllRestaurants().stream()
            .map(restaurant -> modelMapper.map(restaurant, RestaurantDto2.class)).toList();
  }

  /**
   * Adds item.
   */
  @PostMapping(value = "/")
  public ResponseEntity<RestaurantDto> addRestaurant(@RequestBody RestaurantDto restdto) {
    Restaurant restRequest = modelMapper.map(restdto, Restaurant.class);
    Restaurant rest = restServ.addRestaurant(restRequest);

    modelMapper.map(rest, RestaurantDto.class);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  /**
   * Updates item.
   */
  @PutMapping(value = "/{id}")
  public ResponseEntity<RestaurantDto> updateRestaurant(@PathVariable Integer id,
                                                        @RequestBody RestaurantDto restdto) {
    Restaurant restRequest = modelMapper.map(restdto, Restaurant.class);
    Restaurant rest = restServ.updateRestaurant(restRequest);

    modelMapper.map(rest, RestaurantDto.class);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  /**
   * Deletes item.
   */
  @DeleteMapping(value = "/{id}")
  public void deleteRestaurant(@PathVariable Integer id) {
    restServ.deleteRestaurant(id);
  }
}
