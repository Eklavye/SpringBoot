package com.order.project.services;

import com.order.project.entity.OpHrs;
import com.order.project.entity.Restaurant;
import com.order.project.repository.OpRepository;
import com.order.project.service.OpServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class OpHrsServiceTest {

    @Mock
    private OpRepository oprepo;

    @InjectMocks
    private OpServiceImpl opsi;

    private OpHrs oph;

    @BeforeEach
    public void setup() {
        oph = OpHrs.builder()
                .opid(1)
                .dayofweek("Mon, Wed")
                .start("09:00")
                .end("21:00")
                .restaurant(new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245"))
                .build();
    }

    @Test
    void getAllOpHrsTest(){
        OpHrs oph1 = OpHrs.builder().
                opid(2)
                .dayofweek("Sat, Sun")
                .start("09:30")
                .end("13:30")
                .restaurant(new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245"))
                .build();

        given(oprepo.findAll()).willReturn(List.of(oph, oph1));

        List<OpHrs> opHrsList = opsi.getAllOpHrs();
        assertThat(opHrsList).isNotNull();
        assertEquals(2, opHrsList.size());
    }

    @Test
    void addOpHrTest() {

        OpHrs oph1 = OpHrs.builder().
                opid(2)
                .dayofweek("Sat, Sun")
                .start("09:30")
                .end("13:30")
                .restaurant(new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245"))
                .build();

        OpHrs addedOp = opsi.addItem(oph1);

        assertThat(oph1.getOpid()).isEqualTo(2);

    }

    @Test
    void updateOpHrTest() {
        given(oprepo.save(oph)).willReturn(oph);
        oph.setDayofweek("Mon, Tue, Wed, Thu");
        OpHrs updatedOpHr = opsi.updateItem(oph);

        assertThat(updatedOpHr.getDayofweek()).isEqualTo("Mon, Tue, Wed, Thu");

    }

    @Test
    void deleteOpHrTest() {
        Integer id = 1;
        willDoNothing().given(oprepo).deleteById(id);

        opsi.deleteItem(id);
        verify(oprepo, times(1)).deleteById(id);
    }
}
