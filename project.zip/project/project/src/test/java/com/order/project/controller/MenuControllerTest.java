package com.order.project.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.order.project.entity.Category;
import com.order.project.entity.Cuisine;
import com.order.project.entity.Ingredient;
import com.order.project.entity.Menu;
import com.order.project.entity.Restaurant;
import com.order.project.repository.CategoryRepository;
import com.order.project.repository.IngredientRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
class MenuControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private IngredientRepository ingredientRepository;
    @Autowired
    private CategoryRepository categoryRepository;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    void mockGetAllItems() throws Exception {

        MvcResult result = mockMvc.perform(get("/menu/")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andReturn();

        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void mockAddItem() throws Exception {
        Restaurant rest = new Restaurant(1, "Anand Shekhawati", "DCM", "as@gmail.com", "7014922416");
        String jsonRequest = mapper.writeValueAsString(rest);
        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Cuisine cui = new Cuisine(1, "Chinese", rest);
        String jsonRequest1 = mapper.writeValueAsString(cui);
        mockMvc.perform(post("/cui/")
                        .content(jsonRequest1).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Category cat = new Category(1, "Snacks", cui);
        String jsonRequest2 = mapper.writeValueAsString(cat);
        mockMvc.perform(post("/cat/")
                        .content(jsonRequest2).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Ingredient ing = new Ingredient(1, "Aloo Chat", "20-04-2023", 3, 20, rest);
        String jsonRequest3 = mapper.writeValueAsString(ing);
        mockMvc.perform(post("/ing/")
                        .content(jsonRequest3).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Menu item = new Menu(1, "Chilli Potato", rest, cat, cui, ing, 200);
        String jsonRequest4 = mapper.writeValueAsString(item);
        MvcResult result = mockMvc.perform(post("/menu/")
                        .content(jsonRequest4).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, result.getResponse().getStatus());

    }

    @Test
    void mockUpdateItem() throws Exception {
        Restaurant rest = new Restaurant(1, "Anand Shekhawati", "DCM", "as@gmail.com", "7014922416");
        String jsonRequest = mapper.writeValueAsString(rest);
        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Cuisine cui = new Cuisine(1, "Chinese", rest);
        String jsonRequest1 = mapper.writeValueAsString(cui);
        mockMvc.perform(post("/cui/")
                        .content(jsonRequest1).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Category cat = new Category(1, "Snacks", cui);
        String jsonRequest2 = mapper.writeValueAsString(cat);
        mockMvc.perform(post("/cat/")
                        .content(jsonRequest2).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Ingredient ing = new Ingredient(1, "Aloo Chat", "20-04-2023", 3, 20, rest);
        String jsonRequest3 = mapper.writeValueAsString(ing);
        mockMvc.perform(post("/ing/")
                        .content(jsonRequest3).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Menu item = new Menu(1, "Chilli Potato", rest, cat, cui, ing, 200);
        String jsonRequest4 = mapper.writeValueAsString(item);
        mockMvc.perform(post("/menu/")
                        .content(jsonRequest4).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Menu item1 = new Menu(1, "Honey Chilli Potato", rest, cat, cui, ing, 300);
        String jsonRequest5 = mapper.writeValueAsString(item1);
        MvcResult result = mockMvc.perform(put("/menu/1")
                        .content(jsonRequest5).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, result.getResponse().getStatus());

    }

    @Test
    void mockDeleteItem() throws Exception {
        Restaurant rest = new Restaurant(1, "Anand Shekhawati", "DCM", "as@gmail.com", "7014922416");
        String jsonRequest = mapper.writeValueAsString(rest);
        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Cuisine cui = new Cuisine(1, "Chinese", rest);
        String jsonRequest1 = mapper.writeValueAsString(cui);
        mockMvc.perform(post("/cui/")
                        .content(jsonRequest1).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Category cat = new Category(1, "Snacks", cui);
        String jsonRequest2 = mapper.writeValueAsString(cat);
        mockMvc.perform(post("/cat/")
                        .content(jsonRequest2).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Ingredient ing = new Ingredient(1, "Aloo Chat", "20-04-2023", 3, 20, rest);
        String jsonRequest3 = mapper.writeValueAsString(ing);
        mockMvc.perform(post("/ing/")
                        .content(jsonRequest3).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Menu item = new Menu(1, "Chilli Potato", rest, cat, cui, ing, 200);
        String jsonRequest4 = mapper.writeValueAsString(item);
        mockMvc.perform(post("/menu/")
                        .content(jsonRequest4).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        MvcResult result = mockMvc.perform(delete("/menu/1"))
                .andExpect(status().isOk()).andReturn();
        assertEquals(200, result.getResponse().getStatus());
    }
}
