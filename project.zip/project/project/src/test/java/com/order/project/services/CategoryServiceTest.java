package com.order.project.services;

import com.order.project.entity.Category;
import com.order.project.entity.Cuisine;
import com.order.project.repository.CategoryRepository;
import com.order.project.service.CategoryImpl;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
class CategoryServiceTest {
    @Autowired
    private CategoryImpl catsi;

    @MockBean
    private CategoryRepository catrepo;

    @Test
    void getAllCategoryTest() {
        when(catsi.getAllCategory()).thenReturn(Stream.of(new Category(1, "Dessert", new Cuisine())).collect(Collectors.toList()));
        assertEquals(1, catsi.getAllCategory().size());
    }

    @Test
    void addCategoryTest() {
        Category category = new Category(2, "Mocktail", new Cuisine());
        Mockito.when(catrepo.save(category)).thenReturn(category);
        assertEquals((category), (catsi.addItem(category)));
    }

    @Test
    void updateCategoryTest() {
        Category cat = new Category(2, "Main Course", new Cuisine());
        Mockito.when(catrepo.save(cat)).thenReturn(cat);
        assertEquals(catrepo.save(cat), (catsi.updateItem(cat)));
    }

    @Test
    void deleteCategoryTest() {
        Category cat1 = new Category(3, "Snacks", new Cuisine());
        catsi.deleteItem(cat1.getCategoryid());
        verify(catrepo, times(1)).deleteById(3);
    }
}
