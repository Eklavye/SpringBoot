package com.order.project.service;

import com.order.project.entity.Cuisine;
import com.order.project.entity.Restaurant;
import com.order.project.repository.CuisineRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CuisineServiceTest {
    @Mock
    private CuisineRepository cuirepo;

    @InjectMocks
    private CuisineServiceImpl cuiserv;

    private Cuisine cui;

    @BeforeEach
    public void setup() {
        cui = Cuisine.builder()
                .cuisineid(1)
                .cuisinename("Pasta")
                .restaurant(new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245"))
                .build();
    }

    @Test
    void getAllCuisineTest(){
        Cuisine cui1 = Cuisine.builder()
                .cuisineid(2)
                .cuisinename("Pasta")
                .restaurant(new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245"))
                .build();

        given(cuirepo.findAll()).willReturn(List.of(cui, cui1));

        List<Cuisine> cuiList = cuiserv.getAllCuisine();
        assertThat(cuiList).isNotNull();
        assertEquals(2, cuiList.size());
    }

    @Test
    void addCuisineTest() {

        Cuisine cui1 = Cuisine.builder()
                .cuisineid(2)
                .cuisinename("Pasta")
                .restaurant(new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245"))
                .build();


        Cuisine addedCuisine = cuiserv.addItem(cui1);

        assertThat(cui1.getCuisineid()).isEqualTo(2);

    }

    @Test
    void updateCuisineTest() {
        given(cuirepo.save(cui)).willReturn(cui);
        cui.setCuisinename("Pasta");
        Cuisine updatedCuisine = cuiserv.updateItem(cui);

        assertThat(updatedCuisine.getCuisinename()).isEqualTo("Pasta");

    }

    @Test
    void deleteCuisineTest() {
        Integer id = 1;
        willDoNothing().given(cuirepo).deleteById(id);

        cuiserv.deleteItem(id);
        verify(cuirepo, times(1)).deleteById(id);
    }

}