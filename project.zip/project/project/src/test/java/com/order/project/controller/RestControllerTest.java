package com.order.project.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.order.project.entity.Restaurant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
class RestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private ObjectMapper mapper;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    void mockGetAllRestaurants() throws Exception {

        MvcResult result = mockMvc.perform(get("/rests/")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, result.getResponse().getStatus());
    }

    @Test
    void mockAddRestaurant() throws Exception {
        Restaurant restaurant = new Restaurant(3, "Nevaji", "Borkheda", "nj@gmail.com", "9022417414");
        String jsonRequest = mapper.writeValueAsString(restaurant);

        MvcResult result = mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, result.getResponse().getStatus());
    }

    @Test
    void mockUpdateRestaurant() throws Exception{
        Restaurant restaurant1 = new Restaurant(2, "Anand Shekhawati", "DCM", "as@gmail.com", "7014922416");
        String jsonRequest = mapper.writeValueAsString(restaurant1);
        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Restaurant restaurant2 = new Restaurant(2, "Anand Shekhawati", "DCM", "Anand@gmail.com", "7014922416");
        String jsonRequest1 = mapper.writeValueAsString(restaurant2);
        MvcResult result1 = mockMvc.perform(put("/rests/2")
                        .content(jsonRequest1).contentType(MediaType.APPLICATION_JSON))
                        .andExpect(status().isCreated()).andReturn();

        assertEquals(201, result1.getResponse().getStatus());
    }

    @Test
    void mockDeleteRestaurant() throws Exception {
        Restaurant restaurant1 = new Restaurant(1, "Anand Shekhawati", "DCM", "as@gmail.com", "7014922416");
        String jsonRequest = mapper.writeValueAsString(restaurant1);

        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                        .andExpect(status().isCreated()).andReturn();

        MvcResult result = mockMvc.perform(delete("/rests/1"))
                .andExpect(status().isOk()).andReturn();
        assertEquals(200, result.getResponse().getStatus());
    }
}
