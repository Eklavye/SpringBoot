package com.order.project.services;

public class ques {

    arr= [10, 5, 6, 7]
    k=17
    for( int i=1; i<=4; i++)
        for(int j)
}
