package com.order.project.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.order.project.entity.Category;
import com.order.project.entity.Cuisine;
import com.order.project.entity.Restaurant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
class CategoryControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private ObjectMapper mapper;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    void mockGetAllRestaurants() throws Exception {

        MvcResult result = mockMvc.perform(get("/cat/")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andReturn();

        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void mockAddCategory() throws  Exception {
        Restaurant rest = new Restaurant(1, "Anand Shekhawati", "DCM", "as@gmail.com", "7014922416");
        String jsonRequest = mapper.writeValueAsString(rest);

        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Cuisine cui = new Cuisine(1, "chinese", rest);
        String jsonRequest1 = mapper.writeValueAsString(cui);

        mockMvc.perform(post("/cui/")
                        .content(jsonRequest1).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Category cat1 = new Category(1, "Snacks", cui);
        String jsonRequest2 = mapper.writeValueAsString(cat1);

        MvcResult result = mockMvc.perform(post("/cat/")
                        .content(jsonRequest2).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, result.getResponse().getStatus());
    }

    @Test
    void mockUpdateCategory() throws Exception {
        Restaurant rest = new Restaurant(1, "Anand Shekhawati", "DCM", "as@gmail.com", "7014922416");
        String jsonRequest = mapper.writeValueAsString(rest);

        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Cuisine cui = new Cuisine(1, "Chinese", rest);
        String jsonRequest1 = mapper.writeValueAsString(cui);

        mockMvc.perform(post("/cui/")
                        .content(jsonRequest1).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Category cat1 = new Category(1, "Snacks", cui);
        String jsonRequest2 = mapper.writeValueAsString(cat1);

        mockMvc.perform(post("/cat/")
                        .content(jsonRequest2).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Category cat2 = new Category(1, "Starter", cui);
        String jsonRequest3 = mapper.writeValueAsString(cat2);

        MvcResult result = mockMvc.perform(put("/cat/1")
                        .content(jsonRequest3).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, result.getResponse().getStatus());

    }

    @Test
    void mockDeleteCategory() throws Exception {
        Restaurant rest = new Restaurant(1, "Anand Shekhawati", "DCM", "as@gmail.com", "7014922416");
        String jsonRequest = mapper.writeValueAsString(rest);

        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Cuisine cui = new Cuisine(1, "Chinese", rest);
        String jsonRequest1 = mapper.writeValueAsString(cui);

        mockMvc.perform(post("/cui/")
                        .content(jsonRequest1).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Category cat1 = new Category(1, "Snacks", cui);
        String jsonRequest2 = mapper.writeValueAsString(cat1);

        mockMvc.perform(post("/cat/")
                        .content(jsonRequest2).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        MvcResult result = mockMvc.perform(delete("/cat/1"))
                .andExpect(status().isOk()).andReturn();
        assertEquals(200, result.getResponse().getStatus());
    }
}
