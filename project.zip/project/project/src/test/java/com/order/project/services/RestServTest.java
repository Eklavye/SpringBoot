package com.order.project.services;

import com.order.project.entity.Restaurant;
import com.order.project.repository.RestaurantRepository;
import com.order.project.service.RestServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
class RestServTest {
  @Autowired
  private RestServiceImpl restServ;

  @MockBean
  private RestaurantRepository restRepo;

  @Test
  void getAllRestaurantTest() {
    when(restServ.getAllRestaurants()).thenReturn(Stream.of(new Restaurant(2, "Anand Shekhawati", "Near Inox", "as@gmail.com", "7014922416")).collect(Collectors.toList()));
    assertEquals(1, restServ.getAllRestaurants().size());
  }

  @Test
  void addRestaurantTest() {
    Restaurant restaurant = new Restaurant(2, "Anand Shekhawati", "Near Inox", "as@gmail.com", "7014922416");
    Mockito.when(restRepo.save(restaurant)).thenReturn(restaurant);
    assertEquals((restaurant),(restServ.addRestaurant(restaurant)));}

  @Test
  void updateRestaurantTest() {
    Restaurant rest = new Restaurant(1, "Anand Shekhawati", "Near Inox", "as@gmail.com", "7014922416");
    Mockito.when(restRepo.save(rest)).thenReturn(rest);
    assertEquals((rest),(restServ.updateRestaurant(rest)));
  }

  @Test
  void deleteRestaurantTest() {
    Restaurant restaurant1 = new Restaurant(2, "Anand Shekhawati", "Near Inox", "as@gmail.com", "7014922416");
    restServ.deleteRestaurant(restaurant1.getRestaurantid());
    verify(restRepo, times(1)).deleteById(2);
  }
}
