package com.order.project.service;

import com.order.project.entity.Ingredient;
import com.order.project.entity.Restaurant;
import com.order.project.repository.IngredientRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class IngredientServiceTest {

    @Mock
    private IngredientRepository ingrepo;

    @InjectMocks
    private IngredientServiceImpl ingserv;

    private Ingredient ing;

    @BeforeEach
    public void setup() {
        ing = Ingredient.builder()
                .ingredientid(1)
                .ingredientname("Pasta")
                .restaurant(new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245"))
                .build();
    }

    @Test
    void getAllIngredientTest(){
        Ingredient ing1 = Ingredient.builder()
                .ingredientid(2)
                .ingredientname("Pasta")
                .restaurant(new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245"))
                .build();

        given(ingrepo.findAll()).willReturn(List.of(ing, ing1));

        List<Ingredient> ingList = ingserv.getAllIngredient();
        assertThat(ingList).isNotNull();
        assertEquals(2, ingList.size());
    }

    @Test
    void addIngredientTest() {

        Ingredient ing1 = Ingredient.builder()
                .ingredientid(2)
                .ingredientname("Pasta")
                .restaurant(new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245"))
                .build();


        Ingredient addedIngredient = ingserv.addItem(ing1);

        assertThat(ing1.getIngredientid()).isEqualTo(2);

    }

    @Test
    void updateIngredientTest() {
        given(ingrepo.save(ing)).willReturn(ing);
        ing.setIngredientname("Pasta");
        Ingredient updatedIngredient = ingserv.updateItem(ing);

        assertThat(updatedIngredient.getIngredientname()).isEqualTo("Pasta");

    }

    @Test
    void deleteIngredientTest() {
        Integer id = 1;
        willDoNothing().given(ingrepo).deleteById(id);

        ingserv.deleteItem(id);
        verify(ingrepo, times(1)).deleteById(id);
    }

}