package com.order.project.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.order.project.entity.Ingredient;
import com.order.project.entity.Restaurant;
import com.order.project.repository.IngredientRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
class IngredientControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private IngredientRepository ingredientRepository;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    void mockGetAllIngredients() throws Exception {

        MvcResult result = mockMvc.perform(get("/ing/")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andReturn();

        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void mockAddIngredient() throws  Exception {
        Restaurant rest = new Restaurant(1, "Anand Shekhawati", "DCM", "as@gmail.com", "7014922416");
        String jsonRequest = mapper.writeValueAsString(rest);
        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();


        Ingredient ing1 = new Ingredient(1,"Aloo Chat","20-04-2023",3,20,rest);
        String jsonRequest2 = mapper.writeValueAsString(ing1);

        MvcResult result = mockMvc.perform(post("/ing/")
                        .content(jsonRequest2).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, result.getResponse().getStatus());
    }

    @Test
    void mockUpdateIngredient() throws Exception {
        Restaurant rest = new Restaurant(1, "Anand Shekhawati", "DCM", "as@gmail.com", "7014922416");
        String jsonRequest = mapper.writeValueAsString(rest);
        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Ingredient ing1 = new Ingredient(1,"Aloo Chat","20-04-2023",3,20,rest);
        String jsonRequest2 = mapper.writeValueAsString(ing1);
        mockMvc.perform(post("/ing/")
                        .content(jsonRequest2).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Ingredient ing2 = new Ingredient(1,"Aloo Chat","20-04-2023",3,20,rest);
        String jsonRequest3 = mapper.writeValueAsString(ing2);

        MvcResult result = mockMvc.perform(put("/ing/1")
                        .content(jsonRequest3).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, result.getResponse().getStatus());

    }
    @Test
    void mockDeleteIngredient() throws Exception {
        Restaurant rest = new Restaurant(1, "Anand Shekhawati", "DCM", "as@gmail.com", "7014922416");
        String jsonRequest = mapper.writeValueAsString(rest);
        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        Ingredient ing1 = new Ingredient(1,"aloochat","20feb",3,20,rest);
        String jsonRequest2 = mapper.writeValueAsString(ing1);
        mockMvc.perform(post("/ing/")
                        .content(jsonRequest2).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        MvcResult result = mockMvc.perform(delete("/ing/1"))
                .andExpect(status().isOk()).andReturn();
        assertEquals(200, result.getResponse().getStatus());
    }
}
