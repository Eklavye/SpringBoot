package com.order.project.service;

import com.order.project.entity.Cuisine;
import com.order.project.entity.Ingredient;
import com.order.project.entity.Menu;
import com.order.project.entity.Restaurant;
import com.order.project.repository.MenuRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class MenuServiceTest {
    @Mock
    private MenuRepository menurepo;

    @InjectMocks
    private MenuServiceImpl menuserv;

    private Menu menu;

    @BeforeEach
    public void setup() {
        menu = Menu.builder()
                .itemid(1)
                .itemname("Pasta")
                .price(100)
                .restaurant(new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245"))
                .cuisine(new Cuisine())
                .ingredient(new Ingredient())
                .build();
    }

    @Test
    void getAllItemTest(){
        Menu menu1 = Menu.builder()
                .itemid(2)
                .itemname("Pasta")
                .price(100)
                .restaurant(new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245"))
                .cuisine(new Cuisine())
                .ingredient(new Ingredient())
                .build();

        given(menurepo.findAll()).willReturn(List.of(menu, menu1));

        List<Menu> menuList = menuserv.getAllItem();
        assertThat(menuList).isNotNull();
        assertEquals(2, menuList.size());
    }

    @Test
    void addItemTest() {

        Menu menu1 = Menu.builder()
                .itemid(2)
                .itemname("Pasta")
                .price(100)
                .restaurant(new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245"))
                .cuisine(new Cuisine())
                .ingredient(new Ingredient())
                .build();


        Menu addedItem = menuserv.addItem(menu1);

        assertThat(menu1.getItemid()).isEqualTo(2);

    }

    @Test
    void updateMenuHrTest() {
        given(menurepo.save(menu)).willReturn(menu);
        menu.setItemname("Pasta");
        Menu updatedItem = menuserv.updateItem(menu);

        assertThat(updatedItem.getItemname()).isEqualTo("Pasta");

    }

    @Test
    void deleteItemTest() {
        Integer id = 1;
        willDoNothing().given(menurepo).deleteById(id);

        menuserv.deleteItem(id);
        verify(menurepo, times(1)).deleteById(id);
    }

}