package com.order.project.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.order.project.entity.OpHrs;
import com.order.project.entity.Restaurant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
class OpHrsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private ObjectMapper mapper;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    void mockGetAllOpHrs() throws Exception {

        MvcResult result = mockMvc.perform(get("/op/")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andReturn();

        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void mockAddOphrs() throws Exception{
        Restaurant rest = new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245");
        String jsonRequest = mapper.writeValueAsString(rest);
        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        OpHrs oph = new OpHrs(1, "Mon, Tues, Wed", "08:00", "22:00", rest);
        String jsonRequest1 = mapper.writeValueAsString(oph);
        MvcResult result = mockMvc.perform(post("/op/")
                        .content(jsonRequest1).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, result.getResponse().getStatus());
    }

    @Test
    void mockUpdateOpHrs() throws Exception {
        Restaurant rest = new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245");
        String jsonRequest = mapper.writeValueAsString(rest);
        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        OpHrs oph = new OpHrs(1, "Mon, Tues, Wed", "08:00", "22:00", rest);
        String jsonRequest1 = mapper.writeValueAsString(oph);
        mockMvc.perform(post("/op/")
                        .content(jsonRequest1).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        OpHrs updateoph = new OpHrs(1, "Mon, Tues, Wed, Thu", "08:00", "22:00", rest);
        String jsonRequest2 = mapper.writeValueAsString(updateoph);
        MvcResult result = mockMvc.perform(put("/op/1")
                        .content(jsonRequest2).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, result.getResponse().getStatus());
    }

    @Test
    void mockDeleteOpHrs() throws Exception {
        Restaurant rest = new Restaurant(1 , "Madhushri", "Industrial Area", "ms@gmail.com", "9022413245");
        String jsonRequest = mapper.writeValueAsString(rest);
        mockMvc.perform(post("/rests/")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        OpHrs oph = new OpHrs(1, "Mon, Tues, Wed", "08:00", "22:00", rest);
        String jsonRequest1 = mapper.writeValueAsString(oph);
        mockMvc.perform(post("/op/")
                        .content(jsonRequest1).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        MvcResult result = mockMvc.perform(delete("/op/1"))
                .andExpect(status().isOk()).andReturn();
        assertEquals(200, result.getResponse().getStatus());
    }
}
