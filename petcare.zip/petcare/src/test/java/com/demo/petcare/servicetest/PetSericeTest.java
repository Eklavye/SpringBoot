package com.demo.petcare.servicetest;

import com.demo.petcare.dto.PetDto;
import com.demo.petcare.model.Pet;
import com.demo.petcare.repository.PetRepo;
import com.demo.petcare.serviceimpl.PetServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@SpringBootTest
class PetTest {
    @Autowired
    private PetServiceImpl service;

    @Mock
    private PetRepo petRepo;

    @Test
    void getAllPetsTest(){

            List<Pet> list = petRepo.findAll();

            List<PetDto> result = service.getAllPets();

            verify(petRepo, times(2)).findAll();

            assertEquals(list, result);
    }


    /*
    @Test
    void addPetTest() {
        PetDto petDto = new PetDto(6, "Grobeller", "Siberian Husky", "Temperature resistance");
        Mockito.when(petRepo.save(petDto)).thenReturn(petDto);
        assertEquals((petDto),(petServ.addPet(petDto)));}
    }
    */

}
