package com.demo.petcare.controllertest;

import com.demo.petcare.dto.OwnerDto;
import com.demo.petcare.dto.PetDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
class OwnerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private ObjectMapper mapper;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    void mockGetAllOwner() throws Exception {

        OwnerDto ownerDto = new OwnerDto(1, "Rahul", "6377869909", "rs@gmail.com", "Pet's left leg is fractured");
        String jsonRequest = mapper.writeValueAsString(ownerDto);

        mockMvc.perform(post("/owner/addOwner")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        MvcResult actualResponse = mockMvc.perform(get("/owner/getAllOwners")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()
                ).andReturn();

        assertEquals(200, actualResponse.getResponse().getStatus());
    }

    @Test
    void mockAddOwner() throws Exception {
        OwnerDto ownerDto = new OwnerDto(1, "Rahul", "6377869909", "rs@gmail.com", "Pet's left leg is fractured");
        String jsonRequest = mapper.writeValueAsString(ownerDto);

        MvcResult actualResponse = mockMvc.perform(post("/owner/addOwner")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, actualResponse.getResponse().getStatus());
    }

    @Test
    void mockUpdateOwner() throws Exception {
        OwnerDto ownerDto = new OwnerDto(1, "Rahul", "6377869909", "rs@gmail.com", "Pet's left leg is fractured");
        String jsonRequest = mapper.writeValueAsString(ownerDto);
        mockMvc.perform(post("/owner/addOwner")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        OwnerDto updateOwnerDto = new OwnerDto(1, "Rahul", "6377869909", "rs@gmail.com", "Pet's right leg is fractured");
        String jsonRequestUpdated = mapper.writeValueAsString(updateOwnerDto);
        MvcResult actualResponse = mockMvc.perform(put("/owner/updateOwner/1")
                        .content(jsonRequestUpdated).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, actualResponse.getResponse().getStatus());
    }

    @Test
    void mockDeleteOwner() throws Exception {
        OwnerDto ownerDto = new OwnerDto(1, "Rahul", "6377869909", "rs@gmail.com", "Pet's left leg is fractured");
        String jsonRequest = mapper.writeValueAsString(ownerDto);

        mockMvc.perform(post("/owner/addOwner")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        MvcResult actualResponse = mockMvc.perform(delete("/owner/deleteOwner/1"))
                .andExpect(status().isOk()).andReturn();
        assertEquals(200, actualResponse.getResponse().getStatus());
    }

}
