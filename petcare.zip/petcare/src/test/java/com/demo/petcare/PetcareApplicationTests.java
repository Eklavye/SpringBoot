package com.demo.petcare;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetcareApplicationTests {

	@Test
	void contextLoads() {
		Assertions.assertDoesNotThrow(this::donotThrowException);
	}

	private void donotThrowException() {
		//This method will never throw exception.
	}

}
