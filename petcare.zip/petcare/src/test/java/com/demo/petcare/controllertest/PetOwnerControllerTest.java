package com.demo.petcare.controllertest;

import com.demo.petcare.dto.OwnerDto;
import com.demo.petcare.dto.PetDto;
import com.demo.petcare.dto.PetOwnerDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
class PetOwnerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private ObjectMapper mapper;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    void mockGetAllPetOwner() throws Exception {

        PetOwnerDto petOwnerDto = new PetOwnerDto(1, new PetDto(), new OwnerDto());
        String jsonRequest = mapper.writeValueAsString(petOwnerDto);

        mockMvc.perform(post("/petOwner/addPetOwner")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        MvcResult actualResponse = mockMvc.perform(get("/petOwner/getAllPetOwners")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()
                ).andReturn();

        assertEquals(200, actualResponse.getResponse().getStatus());
    }

    @Test
    void mockAddPetOwner() throws Exception {
        PetOwnerDto petOwnerDto = new PetOwnerDto(1, new PetDto(), new OwnerDto());
        String jsonRequest = mapper.writeValueAsString(petOwnerDto);

        MvcResult actualResponse = mockMvc.perform(post("/petOwner/addPetOwner")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, actualResponse.getResponse().getStatus());
    }

    @Test
    void mockUpdatePetOwner() throws Exception {
        PetOwnerDto petOwnerDto = new PetOwnerDto(1, new PetDto(), new OwnerDto());
        String jsonRequest = mapper.writeValueAsString(petOwnerDto);
        mockMvc.perform(post("/PetOwner/addPetOwner")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        PetOwnerDto updatedPetOwnerDto = new PetOwnerDto(1, new PetDto(), new OwnerDto());
        String jsonRequestUpdated = mapper.writeValueAsString(updatedPetOwnerDto);
        MvcResult actualResponse = mockMvc.perform(put("/petOwner/updatePetOwner/1")
                        .content(jsonRequestUpdated).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, actualResponse.getResponse().getStatus());
    }

    @Test
    void mockDeleteOwner() throws Exception {
        PetOwnerDto petOwnerDto = new PetOwnerDto(1, new PetDto(), new OwnerDto());
        String jsonRequest = mapper.writeValueAsString(petOwnerDto);

        mockMvc.perform(post("/petOwner/addPetOwner")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        MvcResult actualResponse = mockMvc.perform(delete("/petOwner/deletePetOwner/1"))
                .andExpect(status().isOk()).andReturn();
        assertEquals(200, actualResponse.getResponse().getStatus());
    }

}
