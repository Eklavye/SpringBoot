package com.demo.petcare.controllertest;

import com.demo.petcare.dto.PetDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
class PetControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private ObjectMapper mapper;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    void mockGetAllPets() throws Exception {

        PetDto petDto = new PetDto(5, "Sheron", "Labradore", "Allergic to coffee");
        String jsonRequest = mapper.writeValueAsString(petDto);

        mockMvc.perform(post("/pet/addPet")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        MvcResult actualResponse = mockMvc.perform(get("/pet/getAllPets")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()
                ).andReturn();

        assertEquals(200, actualResponse.getResponse().getStatus());
    }

    @Test
    void mockAddPet() throws Exception {
        PetDto petDto = new PetDto(6, "Sheron", "Labradore", "Allergic to coffee");
        String jsonRequest = mapper.writeValueAsString(petDto);

        MvcResult actualResponse = mockMvc.perform(post("/pet/addPet")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, actualResponse.getResponse().getStatus());
    }

    @Test
    void mockUpdatePet() throws Exception {
        PetDto petDto = new PetDto(6, "Sheron", "Labradore", "Allergic to coffee");
        String jsonRequest = mapper.writeValueAsString(petDto);
        mockMvc.perform(post("/pet/addPet")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        PetDto updatedPetDto = new PetDto(6, "Sheron", "Pitbull", "Allergic to coffee");
        String jsonRequest1 = mapper.writeValueAsString(updatedPetDto);
        MvcResult actualResponse = mockMvc.perform(put("/pet/updatePet/6")
                        .content(jsonRequest1).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        assertEquals(201, actualResponse.getResponse().getStatus());
    }

    @Test
    void mockDeletePet() throws Exception {
        PetDto petDto = new PetDto(32, "Dracon", "Labradore", "Allergic to bushes");
        String jsonRequest = mapper.writeValueAsString(petDto);

        mockMvc.perform(post("/pet/addPet")
                        .content(jsonRequest).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated()).andReturn();

        MvcResult actualResponse = mockMvc.perform(delete("/pet/deletePet/32"))
                .andExpect(status().isOk()).andReturn();
        assertEquals(200, actualResponse.getResponse().getStatus());
    }

}
