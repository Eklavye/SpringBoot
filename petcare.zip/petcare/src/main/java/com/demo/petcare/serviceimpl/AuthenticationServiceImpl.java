package com.demo.petcare.serviceimpl;

import com.demo.petcare.AuthDao.AuthenticationRequest;
import com.demo.petcare.AuthDao.AuthenticationResponse;
import com.demo.petcare.model.User;
import com.demo.petcare.repository.UserRepository;
import com.demo.petcare.service.AuthenticationService;
import com.demo.petcare.service.JwtService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthenticationServiceImpl implements AuthenticationService {

    private static final Logger log = LoggerFactory.getLogger(AuthenticationServiceImpl.class);
    private final UserRepository repository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    public AuthenticationResponse register(User user) {

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        log.info(user.toString());
        repository.save(user);

        var jwtToken = jwtService.generateToken(user);

        log.info(jwtToken);
        return AuthenticationResponse.builder()
                .token(jwtToken)
                .build();
    }

    public AuthenticationResponse authenticate(AuthenticationRequest user) {
        log.info(user.toString());

        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        user.getEmail(),
                        user.getPassword()
                )
        );
        var authUser = repository.findByEmail(user.getEmail())
                .orElseThrow();

        log.info(authUser.toString());

        var jwtToken = jwtService.generateToken(authUser);

        return AuthenticationResponse.builder()
                .token(jwtToken)
                .build();
    }

}
