package com.demo.petcare.serviceimpl;

import com.demo.petcare.model.Role;
import com.demo.petcare.model.User;
import com.demo.petcare.repository.UserRepository;
import com.demo.petcare.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public User getByEmail(String email) {
        return userRepository.findByEmail(email).orElseThrow(() -> new NullPointerException("User not found."));
    }

    @Override
    public Integer updateUser(User user, Integer id) {
        Optional<User> optional= userRepository.findById(id);
        if(optional.isEmpty())
            throw new NullPointerException();

        User existingUser = optional.get();

        String firstName = user.getFirstName() == null ? existingUser.getFirstName() : user.getFirstName();
        String lastName = user.getLastName() == null ? existingUser.getLastName() : user.getLastName();
        String password = user.getPassword() == null ? existingUser.getPassword() : passwordEncoder.encode(user.getPassword());
        String email = user.getEmail() == null ? existingUser.getEmail() : user.getEmail();
        Role role = user.getRole() == null ? existingUser.getRole() : user.getRole();

        return userRepository.updateUserDetails(firstName, lastName, email, password, role, id);
    }

    @Override
    public void deleteUser(Integer id) {
        userRepository.deleteById(id);
    }


}
