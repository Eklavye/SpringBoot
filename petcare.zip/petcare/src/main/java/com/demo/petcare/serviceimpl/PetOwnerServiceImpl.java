package com.demo.petcare.serviceimpl;

import com.demo.petcare.dto.PetOwnerDto;
import com.demo.petcare.exception.ResourceNotFoundException;
import com.demo.petcare.model.Owner;
import com.demo.petcare.model.Pet;
import com.demo.petcare.model.PetOwner;
import com.demo.petcare.repository.OwnerRepo;
import com.demo.petcare.repository.PetOwnerRepo;
import com.demo.petcare.repository.PetRepo;
import com.demo.petcare.service.PetOwnerService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PetOwnerServiceImpl implements PetOwnerService {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private PetOwnerRepo petOwnerRepo;
    @Autowired
    private PetRepo petRepo;
    @Autowired
    private OwnerRepo ownerRepo;

    @Override
    public List<PetOwnerDto> getAllPetOwner() {
        List<PetOwner> petOwners = petOwnerRepo.findAll();
        return petOwners.stream().map(petOwner -> modelMapper.map(petOwner, PetOwnerDto.class)).toList();
    }

    @Override
    public PetOwner addPetOwner(PetOwnerDto petOwnerDto, Integer petId, Integer ownerId) {
        Pet pet=this.petRepo.findById(petId)
                .orElseThrow(()->new ResourceNotFoundException("Pet", "Petr Id", petId));

        Owner owner=this.ownerRepo.findById(ownerId)
                .orElseThrow(()->new ResourceNotFoundException("Owner", "Owner Id", ownerId));

        PetOwner petOwner = modelMapper.map(petOwnerDto, PetOwner.class);
        petOwner.setPet(pet);
        petOwner.setOwner(owner);

        return petOwnerRepo.save(petOwner);
    }

    @Override
    public PetOwner updatePetOwner(PetOwnerDto petOwnerDto, Integer id) {
        PetOwner petOwner = petOwnerRepo.findById(id)
                .orElseThrow(()->new ResourceNotFoundException("PetOwner", "Pet Owner Id",id));
        return petOwnerRepo.save(petOwner);
    }

    @Override
    public void deletePetOwner(Integer id) {
        PetOwner petOwner = petOwnerRepo.findById(id)
                .orElseThrow(()->new ResourceNotFoundException("PetOwner", "Pet owner id", id));
        this.petOwnerRepo.delete(petOwner);
    }
}
