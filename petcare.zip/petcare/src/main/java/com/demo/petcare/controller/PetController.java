package com.demo.petcare.controller;

import com.demo.petcare.dto.PetDto;
import com.demo.petcare.model.Pet;
import com.demo.petcare.service.PetService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

/**
 * Controller class for Restaurant.
 */
@RestController
@RequestMapping(value = "/pet")
public class PetController {
    @Autowired
    private PetService petService;

    /**
     *Get all pets.
     */
    @GetMapping("/getAllPets")
    public ResponseEntity<?> getAllPets() {
        try{
            return new ResponseEntity<>(petService.getAllPets(), HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
    /**
     * Adds pet.
     */
    @PostMapping(value = "/addPet")
    public ResponseEntity<?> addPet(@Valid @RequestBody PetDto petdto) {
        try {
            petService.addPet(petdto);
            return new ResponseEntity<String>("Entry inserted successfully!.", HttpStatus.CREATED);
        }catch (Exception e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    /**
     * Updates the pet with the petId.
     **/
    @PutMapping(value = "/updatePet/{id}")
    public ResponseEntity<?> updateRestaurant(@Valid @PathVariable Integer id,
                                                   @RequestBody PetDto petdto) {
        try {
            petService.updatePet(petdto, id);
            return new ResponseEntity<String>("Entry updated successfully!", HttpStatus.CREATED);
        }catch (NullPointerException e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }catch (Exception e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    /**
     * Deletes the pet with the petId.
     */
    @DeleteMapping(value = "/deletePet/{id}")
    public ResponseEntity<String> deletePet(@PathVariable Integer id) {
        petService.deletePet(id);
        return new ResponseEntity<String>("Pet deleted successfully!", HttpStatus.OK);
    }
    /**
     * Gets the pet by name.
     */
    @GetMapping("/getPetByName/{petName}")
    public ResponseEntity<Pet> getPetByPetName(@PathVariable String petName){
        return ResponseEntity.ok(petService.getPetByPetName(petName));
    }
    /**
     * Gets the pet with its id.
     */
    @GetMapping("/getPetById/{id}")
    public List<Pet> getPetByPetId(@PathVariable Integer petId) {
        return petService.getPetByPetId(petId);
    }

}
