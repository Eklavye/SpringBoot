package com.demo.petcare.model;

public enum Role {
    USER,
    ADMIN
}
