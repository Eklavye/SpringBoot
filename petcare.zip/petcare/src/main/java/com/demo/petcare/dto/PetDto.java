package com.demo.petcare.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Dto class for the pet.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PetDto {

    private int petId;

    @NotEmpty
    @Size(min = 5,max = 10, message = "Name must be of 5 characters and maximum of 10 characters.")
    private String petName;

    @NotEmpty
    @Size(min = 5,max = 15, message = "Specie must be of 5 characters and maximum of 15 characters.")
    private String specie;

    @Size(min = 5,max = 100, message = "Note must be of 5 to 100 characters.")
    private String notes;
}
