package com.demo.petcare.controller;

import com.demo.petcare.dto.PetOwnerDto;
import com.demo.petcare.service.PetOwnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/petOwner")
public class PetOwnerController {

    @Autowired
    private PetOwnerService petOwnerService;

    @GetMapping("/getAllPetOwner")
    public ResponseEntity<List<PetOwnerDto>> getAllPetOwner() {
        List<PetOwnerDto> petOwnerDto = petOwnerService.getAllPetOwner();
        return new ResponseEntity<List<PetOwnerDto>>(petOwnerDto,HttpStatus.OK);
    }

    @PostMapping(value = "/addPetOwner/petId/{petId}/ownerId/{ownerId}")
    public ResponseEntity<?> addPetOwner(@RequestBody PetOwnerDto petOwnerDto, @PathVariable Integer petId, @PathVariable Integer ownerId) {
        try {
            petOwnerService.addPetOwner(petOwnerDto, petId, ownerId);
            return new ResponseEntity<String>("Entry added successfully!", HttpStatus.CREATED);
        }catch (Exception e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping(value = "/updatePetOwner/{id}")
    public ResponseEntity<?> updatePetOwner(@PathVariable Integer id,
                                                   @RequestBody PetOwnerDto petOwnerDto) {
        try {
            petOwnerService.updatePetOwner(petOwnerDto, id);
            return new ResponseEntity<String>("Entry updated successfully!", HttpStatus.CREATED);
        }catch (NullPointerException e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }catch (Exception e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping(value = "/deletePetOwner/{id}")
    public void deletePetOwner(@PathVariable Integer id) {
        petOwnerService.deletePetOwner(id);
    }


}
