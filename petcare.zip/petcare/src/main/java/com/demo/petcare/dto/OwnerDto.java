package com.demo.petcare.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OwnerDto {
    private int ownerId;

    @NotEmpty
    @Size(min = 5,max = 20, message = "Name must be of 5 characters and maximum of 20 characters")
    private String name;

    @NotEmpty
    @Size(min = 10,max = 10, message = "mobile must be of 10 characters")
    private String mobile;

    private String email;

    @NotEmpty
    @Size(min = 10,max = 100, message = "Issue must be of 10 characters and maximum of 100 characters")
    private String issues;

}
