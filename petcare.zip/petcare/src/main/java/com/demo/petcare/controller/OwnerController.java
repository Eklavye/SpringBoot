package com.demo.petcare.controller;

import com.demo.petcare.dto.OwnerDto;
import com.demo.petcare.service.OwnerService;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/owner")
public class OwnerController {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private OwnerService ownerService;

    @GetMapping("/getAllOwner")
    public ResponseEntity<?> getAllOwners() {
        try{
            return new ResponseEntity<>(ownerService.getAllOwners(), HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping(value = "/addOwner")
    public ResponseEntity<?> addOwner(@Valid @RequestBody OwnerDto ownerDto) {
        try {
            ownerService.addOwner(ownerDto);
            return new ResponseEntity<String>("Entry inserted successfully!.", HttpStatus.CREATED);
        }catch (Exception e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping(value = "/updateOwner/{id}")
    public ResponseEntity<?> updateOwner(@Valid @PathVariable Integer id,
                                                   @RequestBody OwnerDto ownerDto) {
        try {
            ownerService.updateOwner(ownerDto, id);
            return new ResponseEntity<String>("Entry updated successfully!.", HttpStatus.CREATED);
        }catch (NullPointerException e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }catch (Exception e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping(value = "/deleteOwner/{id}")
    public ResponseEntity<String> deleteOwner(@PathVariable Integer id) {
        ownerService.deleteOwner(id);
        return new ResponseEntity<String>("Owner deleted successfully!", HttpStatus.OK);
    }

}
