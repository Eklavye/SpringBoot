package com.demo.petcare.service;

import com.demo.petcare.dto.OwnerDto;
import com.demo.petcare.model.Owner;

import java.util.List;

public interface OwnerService {
    List<OwnerDto> getAllOwners();

    Owner addOwner(OwnerDto ownerdto);

    Owner updateOwner(OwnerDto ownerdto, Integer id);

    void deleteOwner(Integer id);
}
