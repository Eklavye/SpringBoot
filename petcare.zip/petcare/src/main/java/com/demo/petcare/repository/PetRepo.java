package com.demo.petcare.repository;

import com.demo.petcare.model.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

/**
 * Pet repository interface.
 */
public interface PetRepo extends JpaRepository<Pet, Integer> {
    public Pet findPetByPetName(String petName);

    @Query(value = "select * from pet as p where p.petId = :petId",
            nativeQuery = true)
    List<Pet> findPetByPetId(Integer petId);
}
