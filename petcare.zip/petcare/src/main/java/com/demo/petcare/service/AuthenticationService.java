package com.demo.petcare.service;

import com.demo.petcare.AuthDao.AuthenticationRequest;
import com.demo.petcare.AuthDao.AuthenticationResponse;
import com.demo.petcare.model.User;

public interface AuthenticationService {

    AuthenticationResponse register(User user);

    AuthenticationResponse authenticate(AuthenticationRequest request);
}
