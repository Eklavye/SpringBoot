package com.demo.petcare.service;

import com.demo.petcare.model.User;

public interface UserService {

    User getByEmail(String email);

    Integer updateUser(User user, Integer id);

    void deleteUser(Integer id);
}
