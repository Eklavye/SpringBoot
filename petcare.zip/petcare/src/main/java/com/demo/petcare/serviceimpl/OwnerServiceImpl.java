package com.demo.petcare.serviceimpl;

import com.demo.petcare.dto.OwnerDto;
import com.demo.petcare.exception.ResourceNotFoundException;
import com.demo.petcare.model.Owner;
import com.demo.petcare.repository.OwnerRepo;
import com.demo.petcare.service.OwnerService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class OwnerServiceImpl implements OwnerService {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private OwnerRepo ownerRepo;

    @Override
    public List<OwnerDto> getAllOwners() {
        List<Owner> owners = ownerRepo.findAll();
        return owners.stream().map(owner -> modelMapper.map(owner, OwnerDto.class)).toList();
    }

    @Override
    public Owner addOwner(OwnerDto ownerdto) {
        Owner owner = modelMapper.map(ownerdto, Owner.class);
        return ownerRepo.save(owner);
    }

    @Override
    public Owner updateOwner(OwnerDto ownerdto, Integer id) {
        Owner owner = ownerRepo.findById(id)
                .orElseThrow(()->new ResourceNotFoundException("Owner", "owner id",id));

        owner.setName(owner.getName());
        owner.setEmail(owner.getEmail());
        owner.setMobile(ownerdto.getMobile());
        owner.setIssues(ownerdto.getIssues());
        return ownerRepo.save(owner);
    }

    @Override
    public void deleteOwner(Integer id) {
        Owner owner = ownerRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Owner", "ownerId", id));
        ownerRepo.delete(owner);
    }
}
