package com.demo.petcare.repository;

import com.demo.petcare.model.PetOwner;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PetOwnerRepo extends JpaRepository<PetOwner, Integer> {
}
