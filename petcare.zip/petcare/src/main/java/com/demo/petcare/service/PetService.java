package com.demo.petcare.service;

import com.demo.petcare.dto.PetDto;
import com.demo.petcare.model.Pet;
import java.util.List;

/**
 * Pet service interface.
 */
public interface PetService {

    List<PetDto> getAllPets();

    Pet addPet(PetDto petdto);

    Pet updatePet(PetDto petdto, Integer id);

    void deletePet(Integer id);

    Pet getPetByPetName(String petName);

    List<Pet> getPetByPetId(Integer petId);
}
