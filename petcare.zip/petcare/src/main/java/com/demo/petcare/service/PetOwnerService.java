package com.demo.petcare.service;

import com.demo.petcare.dto.PetOwnerDto;
import com.demo.petcare.model.PetOwner;

import java.util.List;

public interface PetOwnerService {
    List<PetOwnerDto> getAllPetOwner();
    PetOwner addPetOwner(PetOwnerDto petOwnerDto, Integer petId, Integer ownerId);

    PetOwner updatePetOwner(PetOwnerDto petOwnerDto,Integer petOwnerId);

    void deletePetOwner(Integer petOwnerId);
}
