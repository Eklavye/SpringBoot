package com.demo.petcare.serviceimpl;

import com.demo.petcare.dto.PetDto;
import com.demo.petcare.exception.ResourceNotFoundException;
import com.demo.petcare.model.Pet;
import com.demo.petcare.repository.PetRepo;
import com.demo.petcare.service.PetService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Pet service implementation class which implements pet service interface.
 */
@Service
public class PetServiceImpl implements PetService {

    @Autowired
    private PetRepo petRepo;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<PetDto> getAllPets() {
        List<Pet> pet = petRepo.findAll();
        return pet.stream().map(pets -> modelMapper.map(pets, PetDto.class)).toList();
    }

    @Override
    public Pet addPet(PetDto petdto) {
        Pet pet = modelMapper.map(petdto, Pet.class);
        return petRepo.save(pet);
    }

    public Pet updatePet(PetDto petdto, Integer id) {
        Pet pet = petRepo.findById(id)
                .orElseThrow(()->new ResourceNotFoundException("Pet", "pet id",id));

        pet.setPetName(petdto.getPetName());
        pet.setSpecie(petdto.getSpecie());
        pet.setNotes(petdto.getNotes());
        return petRepo.save(pet);
    }

    @Override
    public void deletePet(Integer id) {
        Pet pet = petRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Pet", "id", id));
        petRepo.delete(pet);
    }

    @Override
    public Pet getPetByPetName(String petName) {
        return petRepo.findPetByPetName(petName);
    }

    @Override
    public List<Pet> getPetByPetId(Integer petId) {
        return petRepo.findPetByPetId(petId);
    }

}
